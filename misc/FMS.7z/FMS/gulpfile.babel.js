'use strict';

var helpers = require('./gulp/functions/helpers');

import gulp     from 'gulp';
import plugins  from 'gulp-load-plugins';
import yargs    from 'yargs';
// import promise  from 'es6-promise';

var requireDir = require('require-dir');

// Load all Gulp plugins into one variable
const $ = plugins();

const app = {
    'config': helpers.loadRecursiveConfigs(),
    'tasks': helpers.loadTaskConfigs(),
    'PRODUCTION': !!(yargs.argv.production)
};


/* ==============================
 *  # Functions
 * ============================== */

function defaultTask( done ) {
    helpers.addTasks( gulp, plugins, app, app.tasks, done );
// console.log(gulp.tree());
// console.log(app.tasks);
    done();
}

/* ==============================
 *  # Tasks
 * ============================== */

/**
 * Task: default
 * runs: built task, run-server task
 */
gulp.task('default', defaultTask);

