'use strict';

var helpers = require('./gulp/functions/helpers');

import gulp     from 'gulp';
import plugins  from 'gulp-load-plugins';
import yargs    from 'yargs';
// import promise  from 'es6-promise';

var requireDir = require('require-dir');

// Load all Gulp plugins into one variable
const $ = plugins();

// // Promise Definition for Tasks without Streams or existing Promises
// const Promise = promise.Promise;

// // Check for --production flag
// const PRODUCTION = !!(yargs.argv.production);

const app = {
    'config': helpers.loadRecursiveConfigs(),
    'tasks': helpers.loadTaskConfigs(),
    'PRODUCTION': !!(yargs.argv.production)
};
// console.log(app);



/* ==============================
 *  # Functions
 * ============================== */

function defaultTask(done) {
    let tasks = [];

    if (app.tasks.built) {
        tasks.push(app.tasks.built);
    }

    if (app.tasks.server.deliver) {
        tasks.push(app.tasks.server.deliver);
    }

    if (tasks.length === 0) {
        console.log('No tasks found for function \'defaultTask\'!');
        done();
        return;
    }
    return gulp.series(tasks);
}

/* ==============================
 *  # Tasks
 * ============================== */

/**
 * Task: default
 * runs: built task, run-server task
 */
gulp.task('default', defaultTask);

