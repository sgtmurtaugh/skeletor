module.exports = function (gulp, plugins, app, done) {
     return deliver(gulp, app);
};

/**
 * Start Server and watch Sources
 * @param gulp
 * @param app
 */
function deliver(gulp, app) {
    let tasks = [];
console.log('BAM2!');
    // if (app.tasks.server.startServer) {
    //     tasks.push(app.tasks.server.startServer);
    // }
    //
    // if (app.tasks.watch.watch) {
    //     tasks.push(app.tasks.watch.watch);
    // }
    //
    // if (tasks.length > 0) {
    //     gulp.series(tasks);
    // }
    // else {
    //     console.log('No tasks found for function \'deliver\'!');
    // }
}

// /**
//  * Task: deliver
//  * runs: start-server task, watch task
//  */
// gulp.task('deliver',
//     gulp.series(
//         app.task['start-server'],
//         app.task['watch']
//     )
// );
