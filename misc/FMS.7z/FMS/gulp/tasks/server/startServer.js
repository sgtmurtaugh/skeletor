import browser  from 'browser-sync';

module.exports = function (gulp, plugins, app, done) {
    return startServer(app, done);
};

/**
 * Start a server with BrowserSync to preview the site in
 * @param done
 */
function startServer(app, done) {
    browser.init({
        server: app.config.paths.dist.path,
        port: app.config.vendor.server.development.port
    });
    done();
}

// /**
//  * Task: start-server
//  * runs: startServer function
//  */
// gulp.task('start-server',
//     startServer
// );
