import browser  from 'browser-sync';

module.exports = function (gulp, plugins, app, done) {
    return reloadServer(done);
};

/**
 * Reload the browser with BrowserSync
 */
function reloadServer(done) {
    browser.reload();
    done();
}

// /**
//  * Task: reload-server
//  * runs: reloadServer function
//  */
// gulp.task('reload-server',
//     reloadServer
// );
