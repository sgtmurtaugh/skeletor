// import sherpa   from 'style-sherpa';
//
// module.exports = function (gulp, plugins, app, done) {
//     return generateStyleGuide(done);
// };
//
// // Generate a style guide from the Markdown content and HTML template in styleguide/
// function generateStyleGuide(app, done) {
//     sherpa(
//         'src/styleguide/index.md',
//         {
//             output: app.config.paths.dist + '/styleguide.html',
//             template: 'src/styleguide/template.html'
//         },
//         done
//     );
// }
//
// // /**
// //  * Task: generate-styleguide
// //  * runs: generateStyleguide function
// //  */
// // gulp.task('generate-styleguide',
// //     generateStyleGuide
// // );
