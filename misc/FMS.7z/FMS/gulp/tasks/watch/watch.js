import browser  from 'browser-sync';

module.exports = function (gulp, plugins, app, done) {
    return watch(gulp, app, done);
};

/**
 * Watch for changes to static assets, pages, Sass, and JavaScript
 * @param gulp
 * @param app
 * @param done
 */
function watch(gulp, app, done) {
    // gulp.watch(app.config.paths.assets, gulp.series('copy-assets'));
    // gulp.watch('src/pages/**/*.html').on('change', gulp.series('generate-pages', browser.reload));
    // gulp.watch('src/{layouts,partials}/**/*.html').on('change', gulp.series('update-pages', 'generate-pages', browser.reload));
    // gulp.watch('src/assets/scss/**/*.scss', gulp.series('generate-sass'));
    // gulp.watch('src/assets/js/**/*.js').on('change', gulp.series('generate-javascript', browser.reload));
    // gulp.watch('src/assets/img/**/*').on('change', gulp.series('copy-images', browser.reload));
    // gulp.watch('src/styleguide/**').on('change', gulp.series('generate-styleguide', browser.reload));
    done();
}
