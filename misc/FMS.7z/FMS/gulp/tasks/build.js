var helpers  = require('../functions/helpers');

var gulp;
var plugins;
var app;

module.exports = function ( _gulp, _plugins, _app ) {
    gulp = _gulp;
    plugins = _plugins;
    app = _app;

    helpers.checkTaskDependencies( gulp, plugins, app, app.tasks, [
        'clean',
        'generate-pages',
        'generate-sass',
        'generate-javascript',
        'copy-images',
        'copy-assets'
    ]);

    // gulp.task( 'build',
    //      gulp.series(
    //          'clean',
    //          gulp.parallel(
    //              'generate-pages',
    //              'generate-sass',
    //              'generate-javascript',
    //              'copy-images',
    //              'copy-assets'
    //          )
    //      )
    // );
};
