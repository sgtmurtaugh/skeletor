import panini   from 'panini';

module.exports = function (gulp, plugins, app, done) {
    return updatePages(done);
};

// Load updated HTML templates and partials into Panini
function updatePages(done) {
    panini.refresh();
    done();
}

// /**
//  * Task: update-pages
//  * runs: updatePages function
//  */
// gulp.task('update-pages',
//     updatePages
// );
