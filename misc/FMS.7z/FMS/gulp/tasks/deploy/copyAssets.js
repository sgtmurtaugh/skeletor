module.exports = function (gulp, plugins, app, done) {
    return copyAssets(gulp, app)
};

// Copy files out of the assets folder
// This task skips over the "img", "js", and "scss" folders, which are parsed separately
function copyAssets(gulp, app) {
    return gulp.src(app.config.paths.src.assets)
        .pipe(gulp.dest(app.config.paths.dist.path + '/assets'));
}

// /**
//  * Task: copy-assets
//  * runs: copyAssets function
//  */
// gulp.task('copy-assets',
//     copyAssets
// );
//
