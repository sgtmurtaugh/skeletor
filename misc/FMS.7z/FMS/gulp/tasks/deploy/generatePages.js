import panini   from 'panini';

module.exports = function (gulp, plugins, app, done) {
    return generatePages(gulp, app);
};

// Copy page templates into finished HTML files
function generatePages(gulp, app) {
    return gulp.src(app.config.paths.src.path + '/' + app.config.vendor.panini.root + '/**/*.{html,hbs,handlebars}')
        .pipe(panini({
            root: app.config.paths.src.path + '/' + app.config.vendor.panini.root,
            layouts: app.config.paths.src.path + '/' + app.config.vendor.panini.layouts,
            partials: app.config.paths.src.path + '/' + app.config.vendor.panini.partials,
            data: app.config.paths.src.path + '/' + app.config.vendor.panini.data,
            helpers: app.config.paths.src.path + '/' + app.config.vendor.panini.helpers
        }))
        .pipe(gulp.dest(app.config.paths.dist.path));
}

// /**
//  * Task: generate-pages
//  * runs: generatePages function
//  */
// gulp.task('generate-pages',
//     generatePages
// );
