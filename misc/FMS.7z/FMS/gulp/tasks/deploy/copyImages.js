module.exports = function (gulp, plugins, app, done) {
    return copyImages(gulp, app);
};

/**
 * Copy images to the "dist" folder.
 * In production, the images are compressed
 */
function copyImages(gulp, plugins) {
    return gulp.src(['src/assets/img/{icons,sprites}/**/*', '!src/assets/img/sprites-src'])
        .pipe(plugins.if(app.PRODUCTION, plugins.imagemin({
            progressive: true
        })))
        .pipe(gulp.dest('dist/assets/img'));
}

// /**
//  * Task: copy-images
//  * runs: copyImages function
//  */
// gulp.task('copy-images',
//     copyImages
// );
//
