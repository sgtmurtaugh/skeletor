import rimraf   from 'rimraf';

module.exports = function (gulp, plugins, app, done) {
    return clean(app, done);
};

// Delete the "dist" folder
// This happens every time a build starts
function clean(app, done) {
    rimraf(app.config.paths.dist.path, done);
}

// /**
//  * Task: clean
//  * runs: clean function
//  */
// gulp.task('clean',
//     clean
// );
