module.exports = function (gulp, plugins, app, done) {
    return built;
};

/**
 * Start Server and watch Sources
 * @param gulp
 * @param app
 */
function deliver(gulp, app) {
    let seriesTasks = [];
    let parallelTasks = [];

    if (app.tasks.deploy.clean) {
        // seriesTasks.push(app.tasks.deploy.clean);
        console.log('BAM!');
    }

    // if (app.tasks.deploy.generatePages) {
    //     parallelTasks.push(app.tasks.deploy.generatePages);
    // }
    //
    // if (app.tasks.preprocessors.generateSASS) {
    //     parallelTasks.push(app.tasks.preprocessors.generateSASS);
    // }
    //
    // if (app.tasks.js.generateJavascript) {
    //     parallelTasks.push(app.tasks.js.generateJavascript);
    // }
    //
    // if (app.tasks.deploy.copyImages) {
    //     parallelTasks.push(app.tasks.deploy.copyImages);
    // }
    //
    // if (app.tasks.deploy.copyAssets) {
    //     parallelTasks.push(app.tasks.deploy.copyAssets);
    // }
    //
    // if (parallelTasks.length > 0) {
    //     seriesTasks.push(
    //         gulp.parallel(parallelTasks)
    //     );
    // }
    //

    if (seriesTasks.length > 0) {
        gulp.series(seriesTasks);
    }
    else {
        console.log('No tasks found for function \'deliver\'!');
    }
}

// /**
//  * Task: built
//  * runs: generate-sass task, generate-javascript task, copy-images task
//  */
// gulp.task('built',
//     gulp.series(
//         'clean',
//         gulp.parallel(
//             'generate-pages',
//             'generate-sass',
//             'generate-javascript',
//             'copy-images',
//             'copy-assets'
//         )
//     )
// );
//
