import browser  from 'browser-sync';

module.exports = function (gulp, plugins, app, done) {
    return generateSASS(gulp, plugins, app);
};

/**
 * Compile Sass into CSS
 * In production, the CSS is compressed
 */
function generateSASS(gulp, plugins, app) {
    return gulp.src(app.config.paths.src.sass)
        .pipe(plugins.sourcemaps.init())
        .pipe(plugins.sass({
            includePaths: app.config.paths.src.sass
        })
        .on('error', plugins.sass.logError))
        .pipe(plugins.autoprefixer({
            browsers: app.config.vendor.autoprefixer.compatibility
        }))
        // Comment in the pipe below to run UnCSS in production
        //.pipe($.if(PRODUCTION, $.uncss(UNCSS_OPTIONS)))
        .pipe(plugins.if(app.PRODUCTION, plugins.cssnano()))
        .pipe(plugins.if(!app.PRODUCTION, plugins.sourcemaps.write()))
        .pipe(gulp.dest(app.config.paths.dist.css))
        .pipe(browser.reload({ stream: true }));
}

// /**
//  * Task: generate-sass
//  * runs: generateSASS function
//  */
// gulp.task('generate-sass',
//     generateSASS
// );
