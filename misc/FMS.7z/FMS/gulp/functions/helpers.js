import gulp     from 'gulp';
import plugins  from 'gulp-load-plugins';
import fs       from 'fs';
import path     from 'path';

var requireDir = require('require-dir');

// import promise  from 'es6-promise';
//
// Promise Definition for Tasks without Streams or existing Promises
// const Promise = promise.Promise;


module.exports = {

    'getTask': function (task) {
        return requireDir('../tasks/' + task)(gulp, plugins, config, tasks);
    },

    // 'loadCoreConfig': function () {
    //     return loadConfig('config.json');
    // },

    'loadConfig': function (file) {
        let json = null;
        if (null !== file) {
            let configFile = fs.readFileSync(file, 'utf-8');

            if (null !== configFile) {
                json = JSON.parse(configFile);
            }
        }
        return json;
    },

    'loadRecursiveConfigs': function () {
        return requireDir('../conf', {recurse: true});
    },

    'loadTaskConfigs': function () {
        return requireDir('../tasks', {recurse: true});
    },

    'getFolders': function (dir) {
        return fs.readdirSync(dir)
            .filter(function (file) {
                return fs.statSync(path.join(dir, file)).isDirectory();
            });
    },

    /*
     * getType
     * @param obj
     * @return {string}
     * <p>Checks the type of the given parameter. Returns four different values:
     * <dl>
     *  <dt>'array'</dt>
     *  <dd>If the obj is not null and the method <code>Array.isArray()</code> returns true the String 'array' is returned.</dd>
     *
     *  <dt>'object'</dt>
     *  <dd>If the obj is null or of type Object the String 'object' is returned.</dd>
     *
     *  <dt>'other'</dt>
     *  <dd>If the obj is not null and not one of the types Array, Object and String the value 'other' is returned.</dd>
     *
     *  <dt>'string'</dt>
     *  <dd>If the obj is null or of type String the String 'string' is returned.</dd>
     * </dl>
     */
    'getType': function (obj) {
        let type = 'object';

        if (null !== obj) {
            if (Array.isArray(obj)) {
                type = 'array';
            }
            else
            if (typeof obj === 'string') {
                type = 'string';
            }
            else
            if (typeof obj === 'function') {
                type = 'function';
            }
            else
            if (typeof obj !== 'object') {
                type = 'other';
            }
        }
        return type;
    },

    /*
     * isTypeArray
     * @param obj
     * @return {boolean}
     * <p>Delegates to <code>getType(obj)</code> and returns true if the returned type is 'array' otherwise false.
     */
    'isTypeArray': function (obj) {
        return ('array' === module.exports.getType(obj));
    },

    /*
     * isTypeFunction
     * @param obj
     * @return {boolean}
     * <p>Delegates to <code>getType(obj)</code> and returns true if the returned type is 'function' otherwise false.
     */
    'isTypeFunction': function (obj) {
        return ('function' === module.exports.getType(obj));
    },

    /*
     * isTypeObject
     * @param obj
     * @return {boolean}
     * <p>Delegates to <code>getType(obj)</code> and returns true if the returned type is 'object' otherwise false.
     */
    'isTypeObject': function isTypeObject(obj) {
        return ('object' === module.exports.getType(obj));
    },

    /*
     * isTypeOther
     * @param obj
     * @return {boolean}
     * <p>Delegates to <code>getType(obj)</code> and returns true if the returned type is 'other' otherwise false.
     */
    'isTypeOther': function isTypeOther(obj) {
        return ('other' === module.exports.getType(obj));
    },

    /*
     * isTypeString
     * @param obj
     * @return {boolean}
     * <p>Delegates to <code>getType(obj)</code> and returns true if the returned type is 'string' otherwise false.
     */
    'isTypeString': function isTypeString(obj) {
        return ('string' === module.exports.getType(obj));
    },

    /*
     * isEmpty
     * @param obj
     * @return {boolean}
     * <p>Checks the value depending on the type of the parameter object. Returns true, if the obj is null/'undefined', an
     * empty Array or an empty String, otherwise true will be returned.
     */
    'isEmpty': function (obj) {
        if (null === obj
            || obj === 'undefined') {
            return true;
        }
        else
        if (module.exports.isTypeArray(obj)) {
            return (obj.length === 0);
        }
        else
        if (module.exports.isTypeString(obj)) {
            return (obj.trim().length === 0);
        }
        return false;
    },

    'checkTaskDependencies': function ( gulp, plugins, app, jsonTasks, tasknames, done ) {
        if ( module.exports.isTypeArray( tasknames ) ) {
            for ( let taskname of tasknames ) {
                if ( ! gulp.tree().nodes.hasOwnProperty(taskname) ) {
console.log('missing task : ' + taskname);
                    let taskfunction = module.exports.lookupTaskFunction( gulp, plugins, app, jsonTasks, tasknames, done );
console.log('taskfunction : ' + taskfunction);

                    if ( taskfunction !== null ) {
                        module.exports.addTask( gulp, plugins, app, taskfunction, done )
                    }
                }
            }
        }
    },


    'lookupTaskFunction': function (gulp, plugins, app, jsonTasks, taskname) {
        let taskvalue = null;

        // Wenn das uebergebene jsonTasks Objekt nicht null ist
        if ( module.exports.isTypeObject( jsonTasks ) ) {
            // Wenn ein taskname uebergeben wurde, in dem JSON direkt nach einem Key taskname suchen
            if ( taskname !== null ) {
// TODO: hier wird der Key nicht gefunden!?!?!
console.log('Der wird nicht gefunden!?!?!');

                if ( jsonTasks.hasOwnProperty(taskname) ) {
                    taskvalue = jsonTasks[taskname];
                }

                // Wenn der ermittelte Wert eine Task-Function ist, dann diese zurueckgeben, andernfalls den JSON
                // Baumrekursiv durchsuchen.
                if ( ! module.exports.isTypeFunction( taskvalue ) ) {
                    for ( let key in jsonTasks ) {
                        taskvalue = module.exports.lookupTaskFunction(gulp, plugins, app, jsonTasks[key], taskname);

                        if ( taskvalue !== null ) {
                            break;
                        }
                    }
                }
            }
        }

        return taskvalue;
    },


    'addTasks': function ( gulp, plugins, app, jsonTasks, done ) {
        if ( jsonTasks !== null ) {
// console.log(gulp.tree());
            for (var key in jsonTasks) {
                var value = jsonTasks[key];

// console.log('key: ' + key);
// console.log(gulp.tree()['nodes'][key]);
// console.log(gulp.tree()['nodes'][key]);
// console.log(gulp.tree().nodes[key]);

                if ( ! gulp.tree().nodes.key ) {
                    if ( module.exports.isTypeObject( value ) ) {
                        module.exports.addTasks( gulp, plugins, app, value, done );
                    }
                    else
                    if ( module.exports.isTypeFunction( value ) ) {
                        module.exports.addTask( gulp, plugins, app, value, done );
                    }
                    else {
// TODO
console.log('else: ' + value);
                    }
                }
                else {
console.log('task already registred: ' + key);
                }
            }
        }
    },


    'addTask': function ( gulp, plugins, app, taskfunction, done ) {
        if ( module.exports.isTypeFunction( taskfunction ) ) {
            taskfunction( gulp, plugins, app, done );
        }
    }
};
