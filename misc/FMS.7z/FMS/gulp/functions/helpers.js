import gulp     from 'gulp';
import plugins  from 'gulp-load-plugins';
import fs       from 'fs';
import path     from 'path';

var requireDir = require('require-dir');

// import promise  from 'es6-promise';
//
// Promise Definition for Tasks without Streams or existing Promises
// const Promise = promise.Promise;


module.exports = {

    'getTask': function (task) {
        return requireDir('../tasks/' + task)(gulp, plugins, config, tasks);
    },

    // 'loadCoreConfig': function () {
    //     return loadConfig('config.json');
    // },

    'loadConfig': function (file) {
        let json = null;
        if (null !== file) {
            let configFile = fs.readFileSync(file, 'utf-8');

            if (null !== configFile) {
                json = JSON.parse(configFile);
            }
        }
        return json;
    },

    'loadRecursiveConfigs': function () {
        return requireDir('../conf', {recurse: true});
    },

    'loadTaskConfigs': function () {
        return requireDir('../tasks', {recurse: true});
    },

    'getFolders': function (dir) {
        return fs.readdirSync(dir)
            .filter(function (file) {
                return fs.statSync(path.join(dir, file)).isDirectory();
            });
    }
};
